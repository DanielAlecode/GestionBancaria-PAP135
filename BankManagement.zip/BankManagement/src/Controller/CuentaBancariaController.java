
package Controller;

import static Controller.ControllerUsuarios.Url;

public class CuentaBancariaController {
    public static String nombre;
    public static String Num_Cuenta;
    public static double Saldo;

    public CuentaBancariaController() {
    }

    public static String getNombre() {
        return nombre;
    }

    public static void setNombre(String nombre) {
        CuentaBancariaController.nombre = nombre;
    }

    public static String getNum_Cuenta() {
        return Num_Cuenta;
    }

    public static void setNum_Cuenta(String Num_Cuenta) {
        CuentaBancariaController.Num_Cuenta = Num_Cuenta;
    }

    public static double getSaldo() {
        return Saldo;
    }

    public static void setSaldo(double Saldo) {
        CuentaBancariaController.Saldo = Saldo;
    }
    public static boolean CrearUsuario(){
        Model.CuentaBancariaModelo userCB=new Model.CuentaBancariaModelo();
        return userCB.createUser(nombre, Num_Cuenta, Saldo, Url);
    }

}
