package org.netbeans.lib.awtextra;

public class AbsoluteConstraints {

}
